#region Copyright & License Information
/*
 * Copyright (c) The OpenRA Developers and Contributors
 * This file is part of OpenRA, which is free software. It is made
 * available to you under the terms of the GNU General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version. For more
 * information, see COPYING.
 */
#endregion

using System;
using System.Collections.Frozen;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using OpenRA.FileSystem;
using OpenRA.Graphics;
using OpenRA.Primitives;
using OpenRA.Video;
using OpenRA.Widgets;
using FS = OpenRA.FileSystem.FileSystem;

namespace OpenRA
{
	public interface IGlobalModData { }

	/// <summary>
	/// Allows a mod-defined global data module to select a deterministic subset of
	/// manifest files. Files listed as managed remain visible to lint/update tools,
	/// but only their active subset is loaded by the running game.
	/// </summary>
	public interface IModFileConfiguration : IGlobalModData
	{
		IReadOnlyCollection<string> ManagedRules { get; }
		IReadOnlyCollection<string> ActiveRules { get; }
		IReadOnlyCollection<string> ManagedWeapons { get; }
		IReadOnlyCollection<string> ActiveWeapons { get; }
		IReadOnlyCollection<string> ManagedSequences { get; }
		IReadOnlyCollection<string> ActiveSequences { get; }
		IReadOnlyCollection<string> ManagedCursors { get; }
		IReadOnlyCollection<string> ActiveCursors { get; }
		IReadOnlyCollection<string> ManagedChrome { get; }
		IReadOnlyCollection<string> ActiveChrome { get; }
		IReadOnlyCollection<string> ManagedVoices { get; }
		IReadOnlyCollection<string> ActiveVoices { get; }
		IReadOnlyCollection<string> ManagedNotifications { get; }
		IReadOnlyCollection<string> ActiveNotifications { get; }
		IReadOnlyCollection<string> ManagedMusic { get; }
		IReadOnlyCollection<string> ActiveMusic { get; }
		string GameplayFingerprint { get; }
		string PresentationFingerprint { get; }
	}

	public sealed class ModData : IDisposable
	{
		public readonly Manifest Manifest;
		public readonly ObjectCreator ObjectCreator;
		public readonly WidgetLoader WidgetLoader;
		public readonly MapCache MapCache;
		public readonly IPackageLoader[] PackageLoaders;
		public readonly ISoundLoader[] SoundLoaders;
		public readonly ISpriteLoader[] SpriteLoaders;
		public readonly ISpriteSequenceLoader SpriteSequenceLoader;
		public readonly IVideoLoader[] VideoLoaders;
		public readonly HotkeyManager Hotkeys;
		public readonly IFileSystemLoader FileSystemLoader;
		public readonly FrozenDictionary<string, CursorSequence> Cursors;
		public readonly ImmutableArray<string> Rules;
		public readonly ImmutableArray<string> Weapons;
		public readonly ImmutableArray<string> Sequences;
		public readonly ImmutableArray<string> CursorDefinitions;
		public readonly ImmutableArray<string> Chrome;
		public readonly ImmutableArray<string> Voices;
		public readonly ImmutableArray<string> Notifications;
		public readonly ImmutableArray<string> Music;
		public readonly string GameplayFingerprint;
		public readonly string PresentationFingerprint;

		public ILoadScreen LoadScreen { get; }
		public FS ModFiles;
		public IReadOnlyFileSystem DefaultFileSystem => ModFiles;

		readonly Lazy<Ruleset> defaultRules;
		public Ruleset DefaultRules => defaultRules.Value;

		readonly Lazy<IReadOnlyDictionary<string, ITerrainInfo>> defaultTerrainInfo;
		public IReadOnlyDictionary<string, ITerrainInfo> DefaultTerrainInfo => defaultTerrainInfo.Value;

		readonly TypeDictionary modules = [];

		public ModData(Manifest mod, InstalledMods mods, bool useLoadScreen = false)
		{
			Languages = [];

			// Take a local copy of the manifest
			Manifest = new Manifest(mod.Id, mod.Package);
			ObjectCreator = new ObjectCreator(Manifest, mods);
			PackageLoaders = ObjectCreator.GetLoaders<IPackageLoader>(Manifest.PackageFormats, "package");
			ModFiles = new FS(mod.Id, mods, PackageLoaders);

			FileSystemLoader = ObjectCreator.GetLoader<IFileSystemLoader>(Manifest.FileSystem.Value, "filesystem");
			FieldLoader.Load(FileSystemLoader, Manifest.FileSystem);
			FileSystemLoader.Mount(Manifest, ModFiles, ObjectCreator);
			ModFiles.TrimExcess();

			foreach (var kv in Manifest.GlobalModData)
			{
				var t = ObjectCreator.FindType(kv.Key);
				if (t == null || !typeof(IGlobalModData).IsAssignableFrom(t))
					throw new InvalidDataException($"`{kv.Key}` is not a valid mod manifest entry.");

				IGlobalModData module;
				var ctor = t.GetConstructor([typeof(MiniYaml)]);
				if (ctor != null)
				{
					// Class has opted-in to DIY initialization
					module = (IGlobalModData)ctor.Invoke([kv.Value]);
				}
				else
				{
					// Automatically load the child nodes using FieldLoader
					module = ObjectCreator.CreateObject<IGlobalModData>(kv.Key);
					FieldLoader.Load(module, kv.Value);
				}

				modules.Add(module);
			}

			var fileConfigurations = modules.WithInterface<IModFileConfiguration>().ToArray();
			Rules = ConfigureFiles(Manifest.Rules, fileConfigurations, c => c.ManagedRules, c => c.ActiveRules);
			Weapons = ConfigureFiles(Manifest.Weapons, fileConfigurations, c => c.ManagedWeapons, c => c.ActiveWeapons);
			Sequences = ConfigureFiles(Manifest.Sequences, fileConfigurations, c => c.ManagedSequences, c => c.ActiveSequences);
			CursorDefinitions = ConfigureFiles(Manifest.Cursors, fileConfigurations, c => c.ManagedCursors, c => c.ActiveCursors);
			Chrome = ConfigureFiles(Manifest.Chrome, fileConfigurations, c => c.ManagedChrome, c => c.ActiveChrome);
			Voices = ConfigureFiles(Manifest.Voices, fileConfigurations, c => c.ManagedVoices, c => c.ActiveVoices);
			Notifications = ConfigureFiles(Manifest.Notifications, fileConfigurations, c => c.ManagedNotifications, c => c.ActiveNotifications);
			Music = ConfigureFiles(Manifest.Music, fileConfigurations, c => c.ManagedMusic, c => c.ActiveMusic);
			GameplayFingerprint = JoinFingerprints(fileConfigurations.Select(c => c.GameplayFingerprint));
			PresentationFingerprint = JoinFingerprints(fileConfigurations.Select(c => c.PresentationFingerprint));

			FluentProvider.Initialize(Manifest, DefaultFileSystem);

			if (useLoadScreen)
			{
				LoadScreen = ObjectCreator.CreateObject<ILoadScreen>(Manifest.LoadScreen.Value);
				LoadScreen.Init(Manifest, DefaultFileSystem);
				LoadScreen.Display();
			}

			WidgetLoader = new WidgetLoader(Manifest, DefaultFileSystem);
			MapCache = new MapCache(Manifest, ModFiles);

			SoundLoaders = ObjectCreator.GetLoaders<ISoundLoader>(Manifest.SoundFormats, "sound");
			SpriteLoaders = ObjectCreator.GetLoaders<ISpriteLoader>(Manifest.SpriteFormats, "sprite");
			VideoLoaders = ObjectCreator.GetLoaders<IVideoLoader>(Manifest.VideoFormats, "video");
			SpriteSequenceLoader = ObjectCreator.GetLoader<ISpriteSequenceLoader>(Manifest.SpriteSequenceFormat, "sequence");
			Hotkeys = new HotkeyManager(ModFiles, ObjectCreator, Manifest);
			Cursors = ParseCursors(CursorDefinitions, DefaultFileSystem);

			defaultRules = Exts.Lazy(() => Ruleset.LoadDefaults(this));
			defaultTerrainInfo = Exts.Lazy(() =>
			{
				var terrainType = ObjectCreator.FindType(Manifest.TerrainFormat + "Loader");
				var terrainCtor = terrainType?.GetConstructor([typeof(ModData)]);
				if (terrainType == null || !terrainType.GetInterfaces().Contains(typeof(ITerrainLoader)) || terrainCtor == null)
					throw new InvalidOperationException($"Unable to find a terrain loader for type '{Manifest.TerrainFormat}'.");

				var items = new Dictionary<string, ITerrainInfo>();
				var terrainLoader = (ITerrainLoader)terrainCtor.Invoke([this]);
				foreach (var file in Manifest.TileSets)
				{
					var t = terrainLoader.ParseTerrain(DefaultFileSystem, file);
					items.Add(t.Id, t);
				}

				return (IReadOnlyDictionary<string, ITerrainInfo>)new ReadOnlyDictionary<string, ITerrainInfo>(items);
			});

			initialThreadId = Environment.CurrentManagedThreadId;
		}

		static ImmutableArray<string> ConfigureFiles(
			ImmutableArray<string> defaults,
			IEnumerable<IModFileConfiguration> configurations,
			Func<IModFileConfiguration, IReadOnlyCollection<string>> managedSelector,
			Func<IModFileConfiguration, IReadOnlyCollection<string>> activeSelector)
		{
			var configurationArray = configurations.ToArray();
			var managed = configurationArray.SelectMany(managedSelector).ToHashSet();
			return defaults.Where(f => !managed.Contains(f))
				.Concat(configurationArray.SelectMany(activeSelector))
				.Distinct()
				.ToImmutableArray();
		}

		static string JoinFingerprints(IEnumerable<string> fingerprints)
		{
			var values = fingerprints.Where(f => !string.IsNullOrEmpty(f)).Order().ToArray();
			return values.Length == 0 ? "default" : values.JoinWith("+");
		}

		static FrozenDictionary<string, CursorSequence> ParseCursors(IEnumerable<string> cursorDefinitions, IReadOnlyFileSystem fileSystem)
		{
			var stringPool = new HashSet<string>(); // Reuse common strings in YAML
			var sequenceYaml = MiniYaml.Merge(cursorDefinitions.Select(
				s => MiniYaml.FromStream(fileSystem.Open(s), s, stringPool: stringPool)));

			var cursors = new Dictionary<string, CursorSequence>();
			foreach (var node in sequenceYaml)
				if (node.Key == "Cursors")
					foreach (var fileNode in node.Value.Nodes)
						foreach (var sequenceNode in fileNode.Value.Nodes)
							cursors.Add(sequenceNode.Key, new CursorSequence(
								sequenceNode.Key, fileNode.Key, fileNode.Value.Value, sequenceNode.Value));

			return cursors.ToFrozenDictionary();
		}

		// HACK: Only update the loading screen if we're in the main thread.
		readonly int initialThreadId;
		internal void HandleLoadingProgress()
		{
			if (LoadScreen != null && IsOnMainThread)
				LoadScreen.Display();
		}

		internal bool IsOnMainThread => Environment.CurrentManagedThreadId == initialThreadId;

		public void InitializeLoaders(IReadOnlyFileSystem fileSystem)
		{
			// all this manipulation of static crap here is nasty and breaks
			// horribly when you use ModData in unexpected ways.
			ChromeMetrics.Initialize(this);
			ChromeProvider.Initialize(this);
			Ui.Initialize(this);
			FluentProvider.Initialize(Manifest, fileSystem);

			Game.Sound.Initialize(SoundLoaders, fileSystem);
		}

		public IEnumerable<string> Languages { get; }

		public void PrepareMap(Map map)
		{
			LoadScreen?.Display();

			// Reinitialize all our assets
			InitializeLoaders(map);
			map.Sequences.LoadSprites();

			// Load music with map assets mounted
			using (new Support.PerfTimer("Map.Music"))
				foreach (var entry in map.Rules.Music)
					entry.Value.Load(map);
		}

		public MiniYamlNode[][] GetRulesYaml()
		{
			var stringPool = new HashSet<string>(); // Reuse common strings in YAML
			return Rules.Select(s => MiniYaml.FromStream(DefaultFileSystem.Open(s), s, stringPool: stringPool).ToArray()).ToArray();
		}

		/// <summary>Load a cached IGlobalModData instance.</summary>
		public T GetOrCreate<T>() where T : IGlobalModData
		{
			var module = modules.GetOrDefault<T>();

			// Lazily create the default values if not explicitly defined.
			if (module == null)
			{
				module = (T)ObjectCreator.CreateBasic(typeof(T));
				modules.Add(module);
			}

			return module;
		}

		public T GetOrNull<T>() where T : IGlobalModData
		{
			return modules.GetOrDefault<T>();
		}

		public T GetSettings<T>() where T : SettingsModule
		{
			return Game.Settings.GetOrCreate<T>(ObjectCreator, Manifest.Id);
		}

		public void Dispose()
		{
			LoadScreen?.Dispose();
			MapCache.Dispose();

			ObjectCreator?.Dispose();

			foreach (var module in modules)
			{
				var disposableModule = module as IDisposable;
				disposableModule?.Dispose();
			}
		}
	}

	public interface ILoadScreen : IDisposable
	{
		/// <summary>Initializes the loadscreen with yaml data from the LoadScreen block in mod.yaml.</summary>
		void Init(Manifest manifest, IReadOnlyFileSystem fileSystem);

		/// <summary>Called at arbitrary times during mod load to rerender the loadscreen.</summary>
		void Display();

		/// <summary>
		/// Called before loading the mod assets.
		/// Returns false if mod loading should be aborted (e.g. switching to another mod instead).
		/// </summary>
		bool BeforeLoad(ModData modData);

		/// <summary>Called when the engine expects to connect to a server/replay or load the shellmap.</summary>
		void StartGame(Arguments args);
	}

	public interface IFileSystemLoader
	{
		void Mount(Manifest manifest, FS fileSystem, ObjectCreator objectCreator);
	}
}
